# -*- coding: utf-8 -*-
#########################################################################

{
    'name': 'Transportations',
    'author': 'Shilal',
    'description': 'Module create simple transportations system',
    'summary': """
                
        """,
    'website': "",
    'license': 'OPL-1',
    'version': '14.0',
    'category': 'Accounting',
    'depends': ['fleet','custom_sa_invoice'],
    'data': [
        'security/transport_permisisons.xml',
        'security/ir.model.access.csv',

        'data/sequence_fields.xml',
        'data/product_data.xml',

        'views/report_invoice.xml',
        'views/res_branch_view.xml',
        'views/fleet_vehicle_cost_views.xml',
        'views/account_move_view.xml',
        'views/res_partner_view.xml',
        'views/movements_view.xml',
        'views/ssc_contract_view.xml',
        'views/menus.xml',
    ],
    'demo': [],
    'images': [
            ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
