# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _
from datetime import date,datetime

class InvoiceReportDetails(models.AbstractModel):
    _name = "report.account.report_invoice_with_payments"
    
    @api.model
    def _get_report_values(self, docids, data=None):
        move_obj = self.env['account.move']
        # data['context'] = dict(self.env.context)
        doc_ids = move_obj.search([('id','=',data['model_id'])])
        docs = move_obj.browse(doc_ids)
        return {
            'doc_ids': doc_ids,
            'doc_model': 'account.move',
            # 'data': data,
            'docs':docs
            }
        