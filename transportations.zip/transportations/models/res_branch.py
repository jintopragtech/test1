# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _

class ResBrabch(models.Model):
    _name = 'res.branch'

    name = fields.Char(string="Name", required=True)
    company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.user.company_id)
    number = fields.Char(string="Number")

    
       