# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _

class SscContract(models.Model):
    _name = 'ssc.contract'

    name = fields.Char(string="Contract Name", required=True)
    company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.user.company_id)
    contract_date = fields.Date(string="Contract Date", default=fields.Date.today())
    customer_id = fields.Many2one('res.partner', string="Customer", required=True)
    reference = fields.Char(string="Reference")
    tax_ids = fields.Many2many('account.tax', string="Taxes")
    state = fields.Selection([('draft','Draft'),
        ('open','Open'),
        ('close','Closed')],
        default="draft")
    has_invoice = fields.Boolean(default=False)
    invoices_number = fields.Integer(string="Invoices", compute='get_contract_invoice')
    line_ids = fields.One2many('ssc.contract.line', 'ssc_contract_id' , string="Contract Lines")

    def action_confirm_all(self):
        self.state = 'open'
        self.action_close()
        self.create_invice()


    def action_confirm(self):
        self.state = 'open'

    def action_close(self):
        self.state = 'close'

    def action_to_draft(self):
        account_move_obj = self.env['account.move']
        account_move_ids = account_move_obj.search([('ssc_contract_id','=',self.id),('state','=','draft')])
        for invoice in account_move_ids:
            invoice.unlink()
        if self.has_invoice == True:
            self.write({'has_invoice':False})
        self.state = 'draft'

    def update_invice(self):
        account_move_ids = self.env['account.move'].search([('ssc_contract_id','=',self.id)])
        for invoice in account_move_ids:
            for line in invoice.invoice_line_ids:
                line.price_unit = self.calculate_price_unit()
                line.tax_ids = self.tax_ids.ids


    def get_contract_invoice(self):
        invoices_number = self.env['account.move'].search_count([('ssc_contract_id','=',self.id)])
        if invoices_number:
            self.invoices_number = invoices_number
        else:
            self.invoices_number = 0


    def view_contract_invoice(self):
        
        return {
            'name': _('Contract Invoice'),
            'view_id':False,
            # 'view_type': 'tree',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'type':'ir.actions.act_window',
            'context': {},
            'domain':[('ssc_contract_id', '=', self.id)],
        }


    def create_invice(self):
        account_move_obj = self.env['account.move']

        data = {
            'partner_id':self.customer_id.id,
            'company_id':self.company_id.id,
            'state':'draft',
            'move_type':'out_invoice',
            'ssc_contract_id':self.id,
            'contract_type':'delivery_contract',
            'invoice_line_ids':[(0,0,self.get_invoice_line_ids())]
        }
        account_move_obj.sudo().create(data)
        self.write({'has_invoice':True})

    def get_invoice_line_ids(self):
        product_id = self.env['product.product'].search([('default_code','=','trans')])
        val = {
            'product_id': product_id.id,
            'name': product_id.name,
            'price_unit': self.calculate_price_unit(),
            'quantity': 1.0,
            'account_id':product_id.property_account_income_id.id,
            # 'display_type':'line_section',
            'tax_ids':self.tax_ids.ids
        }
        return val

    def calculate_price_unit(self):
        price_unit = 0.0
        for line in self.line_ids:
            price_unit+=line.transportation_fees

        return price_unit

class SscContractLine(models.Model):
    _name = 'ssc.contract.line'

    ssc_contract_id = fields.Many2one('ssc.contract', string="Contract")
    driver_id = fields.Many2one('res.partner', string="Driver", required=True)
    plate = fields.Char(string='Plate')
    transportor_policy = fields.Char(string='Transportor Policy')
    factory_policy = fields.Char(string='Factory Policy')
    weight = fields.Float(string="Weight")
    transportation_fees = fields.Float(string="Transportation Fees")
    date = fields.Date(string="Date", default=fields.Date.today())
    address = fields.Char(string="Sent To")

    
       
