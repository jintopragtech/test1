
from . import account_move
from . import invoice_temp_setting
from . import res_branch
from . import contracts
from . import res_partner
from . import fleet_vehicle
from . import movements
from . import ssc_contract