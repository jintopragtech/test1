# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _

class FleetVehicle(models.Model):
    _inherit = 'fleet.vehicle'

    driver_id = fields.Many2one('res.partner', 
        'Driver', 
        tracking=True, 
        help='Driver of the vehicle', 
        copy=False, 
        domain=[('driver','=',True)])
      