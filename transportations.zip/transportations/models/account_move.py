# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________


from odoo import api, fields, models, _

class AccountMove(models.Model):
    _inherit = 'account.move'


    contract_id = fields.Many2one('fleet.vehicle.log.contract', string="Contract", readonly=True)
    ssc_contract_id = fields.Many2one('ssc.contract', string="Contract", readonly=True)
    contract_type = fields.Selection([('transportation_contract','Transportation Contract'),
        ('delivery_contract','Delivery Contract')],
        default="transportation_contract")
    show_contract = fields.Boolean('Show Contract', compute='is_invoice_has_contract')


    def is_invoice_has_contract(self):
        for rec in self:
            show_contract = True
            if rec.temp_setting_id.invoice_template_id not in ['4','5']:
                show_contract = False
            rec.show_contract = show_contract

    def calaulate_total_tax_amount(self, total, tax_ids):
        percentage = 0.0
        for tax in tax_ids:
            percentage+=tax.amount
        amount = percentage*total/100
        return amount

    @api.model_create_multi
    def create(self, vals_list):
        record = super(AccountMove, self).create(vals_list)
        # record.action_post()
        return record

    
