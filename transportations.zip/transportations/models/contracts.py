# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _
from _datetime import datetime

class FleetVehicleLogContract(models.Model):
    _inherit = 'fleet.vehicle.log.contract'

    branch_id = fields.Many2one('res.branch', string="Branch", required=True)
    movement_id = fields.Many2one('res.movements', string="Movement")
    sequence = fields.Char(string="Sequence", readonly=True)
    contract_lable = fields.Text(string="Lable")
    packages_num = fields.Integer(string="Packages Number")

    rant_amount = fields.Float(string="Rant Amount", required=True)
    branch_rant_amount = fields.Float(string=" Branhc Rant Amount")
    s_branch_rant_amount = fields.Float(string="Rant Amount")
    invoices_number = fields.Integer(string="Invoices", compute='get_contract_invoice')
    has_invoice = fields.Boolean()
    tax_ids = fields.Many2many('account.tax', string="Taxes")
    # rant_tax_amount = fields.Float(string="Rant Amount", required=True)
    # office_tax_amount = fields.Float(string="Rant Amount")
    # s_office_tax_amount = fields.Float(string="Rant Amount")


    def get_contract_invoice(self):
        invoices_number = self.env['account.move'].search_count([('contract_id','=',self.id)])
        if invoices_number:
            self.invoices_number = invoices_number
        else:
            self.invoices_number = 0


    def view_contract_invoice(self):
        
        return {
            'name': _('Contract Invoice'),
            'view_id':False,
            # 'view_type': 'tree',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'type':'ir.actions.act_window',
            'context': {},
            'domain':[('contract_id', '=', self.id)],
        }


    @api.model
    def create(self,vals):
        vals['sequence'] = self.env['ir.sequence'].get('fleet.vehicle.log.contract')
        return super(FleetVehicleLogContract, self).create(vals)

    def update_invice(self):
        account_move_ids = self.env['account.move'].search([('contract_id','=',self.id)])
        for invoice in account_move_ids:
            for line in invoice.invoice_line_ids:
                line.price_unit = self.calculate_price_unit()
                line.tax_ids = self.tax_ids.ids


    def downlaod_pdf_invoice(self):

        account_move_obj = self.env['account.move']
        account_move_ids = account_move_obj.search([('contract_id','=',self.id)],limit=1, order='create_date desc')
        data = {
            'model_id': account_move_ids.id,
            }
        # return self.env.ref('account.account_invoices').report_action(None,data)

        return {
            'type': 'ir.actions.act_url',
            'target': 'self',
            'url': account_move_ids.get_portal_url(),
        }

        # account_move_ids.preview_invoice()

        # account_move_obj.downlaod_pdf_invoice(data)
        # return self.env.ref('account.account_invoices').report_action(self,account_move_ids)

        # datas = {
        #     'ids': account_move_ids._ids,
        #     'model':'account.move',
        #     # 'form': invoiceModel.read(),
        #     'context':self._context
        # }
        # return {
        #            'type': 'ir.actions.report',
        #            'report_name': 'account.account_invoices',
        #            'datas': datas
        #        }

        # context = dict(account_move_obj._context or {}, active_ids=account_move_ids.ids, active_model=account_move_obj._name)
        # return {
        #            'type': 'ir.actions.report',
        #            'report_name': 'account.report_invoice_with_payments',
        #            'context': context
        #        }


    def create_invice(self):
        account_move_obj = self.env['account.move']

        date = fields.Date.today()

        data = {
            'partner_id':self.insurer_id.id,
            'invoice_date':str(date),
            'invoice_date':str(date),
            'state':'draft',
            'move_type':'out_invoice',
            'contract_id':self.id,
            'contract_type':'transportation_contract',
            'invoice_line_ids':[(0,0,self.get_invoice_line_ids())]
        }
        account_move_obj.create(data)
        self.write({'has_invoice':True})
        self.contract_close()

    def action_to_futur(self):
        account_move_obj = self.env['account.move']
        account_move_ids = account_move_obj.search([('contract_id','=',self.id),('state','=','draft')])
        for invoice in account_move_ids:
            invoice.unlink()
        self.state = 'futur'

    def get_invoice_line_ids(self):
        product_id = self.env['product.product'].search([('default_code','=','trans')])
        val = {
            'product_id': product_id.id,
            'name': product_id.name,
            'price_unit': self.calculate_price_unit(),
            'quantity': 1.0,
            'account_id':product_id.property_account_income_id.id,
            'parent_state':'draft',
            'display_type':False,
            'tax_ids':self.tax_ids.ids
        }
        return val

    def calculate_price_unit(self):
        price_unit = 0.0
        if self.rant_amount:
            price_unit+= self.rant_amount
        if self.branch_rant_amount:
            price_unit+= self.branch_rant_amount
        if self.s_branch_rant_amount:
            price_unit+= self.s_branch_rant_amount

        return price_unit
        
    
       
