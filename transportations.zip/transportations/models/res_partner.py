# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

from odoo import api, fields, models, _

class ResPartner(models.Model):
    _inherit = 'res.partner'

    driver = fields.Boolean(string="Driver")
    national_id = fields.Char(string="National ID")
      