# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Template for Transportation system
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________


from odoo import api, fields, models, _
from odoo import tools
from odoo.modules.module import get_module_resource
import base64

class InvoiceTempSetting(models.Model):
    _inherit = "invoice.temp.setting"

    invoice_template_id = fields.Selection(selection_add=[('4','Transportation Template'),('5','Delivery Template')] , ondelete={'4':'set default'})


    @api.onchange('invoice_template_id')
    def _set_preview_img(self):
        if self.invoice_template_id in ['4','5']:
            if self.invoice_template_id == '4':
                image_path = get_module_resource('transportations', 'static/src/img', 'temp_ihn_1.png')
            if self.invoice_template_id == '5':
                image_path = get_module_resource('transportations', 'static/src/img', 'temp_ihn_2.png')
        else:
            image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_1.png')

        if image_path:
            self.write(
                {
                'preview_img':base64.b64encode(open(image_path, "rb").read())
                })

