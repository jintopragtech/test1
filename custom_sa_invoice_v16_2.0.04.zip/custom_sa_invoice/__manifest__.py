# -*- coding: utf-8 -*-
#########################################################################
#
#    MyFatoorah Payment Gateway
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________

{
    'name': 'Custom E. Invoice',
    'author': 'Shilal',
    'description': '',
    'summary': """
        
        """,
    'website': "",
    'license': 'OPL-1',
    'version': '14.0',
    'category': 'Account Modules',
    'depends': ['account','l10n_sa'],
    'data': [
        'security/ir.model.access.csv',
        'data/invoice_temp_setting_data.xml',
        'views/account_move_view.xml',
        'views/invoice_temp_setting_view.xml',
        'views/report_invoice.xml',
        'views/res_partner_view.xml',
    ],
    'demo': [],
    'images': [
            ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
