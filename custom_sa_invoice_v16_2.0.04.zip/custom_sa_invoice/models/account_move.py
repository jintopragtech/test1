# -*- coding: utf-8 -*-
#########################################################################
#
#    MyFatoorah Payment Gateway
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________


from odoo import api, fields, models, _
from num2words import num2words


class AccountMove(models.Model):
    _inherit = "account.move"

    temp_setting_id = fields.Many2one('invoice.temp.setting', string="temp setting id", compute='_get_temp_setting_id')
    current_datatime = fields.Datetime(default=lambda self: fields.Datetime.now())

    def _get_temp_setting_id(self):
        invoice_temp_setting_ids = self.env['invoice.temp.setting'].search([('company_id','=',self.company_id.id)])
        if invoice_temp_setting_ids:
            for line in invoice_temp_setting_ids:
                self.temp_setting_id = line.id
        else:
            invoice_temp_setting_ids = self.env['invoice.temp.setting'].search([])
            for line in invoice_temp_setting_ids:
                self.temp_setting_id = line.id

    def remove_zero_fractions(self, number):
        int_number = int(number)
        fractions_vlaue = number-int_number
        if fractions_vlaue > 0:
            return number
        else:
            return int_number

    def calculate_line_discount(self,move_line):
        total_amount = move_line.quantity*move_line.price_unit
        line_discount = 0
        if total_amount != 0 and move_line.discount:
            line_discount = total_amount*move_line.discount/100
        return line_discount

    def set_report_bottom_margin(self,temp_setting_id):
        temp_setting_id.set_report_bottom_margin()
        return "True"

    def calculate_invoice_pos_amount(self,invoice_id):
        total = 0
        for line in invoice_id.invoice_line_ids:
            if line.price_subtotal >= 0:
                total += line.price_subtotal
        if invoice_id.amount_tax:
            total += invoice_id.amount_tax

        total = round(total, 2)

        return total

    def calculate_invoice_neg_amount(self,invoice_id):
        total = 0
        for line in invoice_id.invoice_line_ids:
            if line.price_subtotal < 0:
                total += line.price_subtotal

        total = round(total, 2)

        return total

    def calculate_invoice_discount(self,invoice_id):
        total_discount = 0
        for line in invoice_id.invoice_line_ids:
            line_discount = 0
            total_amount = line.quantity*line.price_unit
            if total_amount != 0 and line.discount:
                line_discount = total_amount*line.discount/100

            total_discount = total_discount+line_discount

        return total_discount

    def amount_as_text(self,amount,lang):
        text = _(str(self.currency_id.with_context(lang=lang).amount_to_text(amount)))
        if lang == 'ar_001':
            text = text.replace("Riyal", "ريال")
            text = text.replace("Halala", "هللة")
            text = text+_(" (المبلغ يشمل ضريبة القيمة المضافة ")
        if lang != 'ar_001':
            text = text.replace("ريال","Riyal")
            text = text.replace("هللة","Halala")

        return text

    def get_all_invoice_variants(self,invoice_lines):
        variants_list = []
        for line in invoice_lines:
            if line.product_id.product_template_attribute_value_ids:
                for attribute in line.product_id.product_template_attribute_value_ids:
                    if attribute.attribute_id.name not in variants_list:
                        variants_list.append(attribute.attribute_id.name)

        return variants_list

    def get_banks_accounts(self):
        banks_accounts = self.env['res.partner.bank'].search([])
        return banks_accounts


class AccountMove(models.Model):
    _inherit = "product.template.attribute.line"

    show_in_invoice = fields.Boolean(string="Show In Invocie", default=True)


class AccountMove(models.Model):
    _inherit = "product.template.attribute.value"

    show_in_invoice = fields.Boolean(string="Show In Invocie", related = 'attribute_line_id.show_in_invoice')




