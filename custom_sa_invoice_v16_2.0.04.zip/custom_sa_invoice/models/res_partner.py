# -*- coding: utf-8 -*-
# ________________________________________________________________________

#    KSA invoice templates
#    Copyright (C) 2021 Shilal Software Center.
# ________________________________________________________________________

from odoo import api, fields, models, _

class ResPartner(models.Model):
    _inherit = "res.partner"

    district = fields.Char(string="District")