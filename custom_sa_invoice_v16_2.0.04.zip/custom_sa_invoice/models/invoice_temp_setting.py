# -*- coding: utf-8 -*-
#########################################################################
#
#    Custom Invoice Templates
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________


from odoo import api, fields, models, _
from odoo import tools
from odoo.modules.module import get_module_resource
from odoo.exceptions import UserError, ValidationError
import base64

class InvoiceTempSetting(models.Model):
    _name = "invoice.temp.setting"

    company_id = fields.Many2one('res.company', string="Company", required=True)
    show_header = fields.Boolean(string="Show Header")
    margin_top = fields.Selection(
        [('0','0 Units'),
        ('5','5 Units'),
        ('10','10 Units'),
        ('15','15 Units'),
        ('20','20 Units'),
        ('25','25 Units'),
        ('30','30 Units'),], 
        string="Margin Top", default='15'
        )
    show_footer = fields.Boolean(string="Show Footer")
    margin_bottom = fields.Selection(
        [('0','0 Units'),
        ('5','5 Units'),
        ('10','10 Units'),
        ('15','15 Units'),
        ('20','20 Units'),
        ('25','25 Units'),
        ('30','30 Units'),],
        string="Margin Bottom", default='15'
        )
    show_tax = fields.Boolean(string="Show Taxes", default=True)
    show_fractios = fields.Boolean(string="Show .00 Fractios", default=True)
    show_variants = fields.Boolean(string="Show Variants")
    product_table = fields.Boolean(string="Show Products in Table")
    partner_labels = fields.Boolean(string="Show Partner Labels")
    barcode_position = fields.Selection([('top','Top'),('bottom','Bottom')], default='top', string="Barcode Position")
    invoice_template_id = fields.Selection(
        [('1','Template 1'),
        # ('2','Template 2'),
        # ('3','Template 3'),
        ('6','Template 2'),
        ('7','Template 3'),
        ('8','Template 4'),], 
        string="Invoice Template", default='1'
        )
    variants_style = fields.Selection(
        [('multi_colons','Multi Colons'),
        ('one_colons','One Colon')], 
        string="Variants Style", default='multi_colons'
        )
    preview_img = fields.Binary(store=True)
    custom_header = fields.Boolean(
        string='Custom Header',
    )
    custom_header_img = fields.Binary(
        string='Custom Header Image',
        attachment=True,
    )
    custom_footer = fields.Boolean(
        string='Custom Footer',
    )
    custom_footer_img = fields.Binary(
        string='Custom Footer Image',
        attachment=True,
    )
    show_company_data_top = fields.Boolean(
        string='Show Company Data Top',
    )
    show_invoice_ref = fields.Boolean(
        string='Show Invoice Reference',
    )
    show_delivery_date = fields.Boolean(
        string='Show Delivery Date',
    )


    @api.model
    def set_company_invoice_template(self):
        company_ids = self.env['res.company'].search([])
        template_obj = self.env['invoice.temp.setting']

        for company in company_ids:
            company_template = template_obj.search([('company_id','=',company.id)])
            if not company_template:
                self.create({
                    'invoice_template_id':'1',
                    'company_id':company.id,
                    })


    @api.constrains('company_id')
    def _check_company_template(self):
        template_ids = self.env['invoice.temp.setting'].search([])
        counter = 0
        for record in template_ids:
            if record.company_id == self.company_id:
                counter += 1
        if counter > 1:
            raise ValidationError(_('You cannot set more than one template for company >>> %s ! ')%(self.company_id.name))


    @api.onchange('invoice_template_id')
    def _set_preview_img_main(self):
        self.set_report_bottom_margin()

        if self.invoice_template_id in ['1','2','3','6','7','8']:
            if self.invoice_template_id == '1':
                image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_1.png')
            if self.invoice_template_id == '2':
                image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_2.png')
            if self.invoice_template_id == '3':
                image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_3.png')
            if self.invoice_template_id in ['6','8']:
                image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_4.png')
            if self.invoice_template_id == '7':
                image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_5.png')
        else:
            image_path = get_module_resource('custom_sa_invoice', 'static/src/img', 'inv_temp_1.png')

        if self.invoice_template_id in ['2','3','6']:
            self.write(
            {
            'show_header': False,
            'show_header': False
            })
        if image_path:
            if self.invoice_template_id in ['1','2','3','6','7','8']:
                self.write(
                    {
                    'preview_img':base64.b64encode(open(image_path, "rb").read())
                    })

        if self.invoice_template_id not in ['6','7','8']:
            self.write(
            {
            'custom_header': False,
            'custom_footer': False
            })


    @api.depends('invoice_template_id')
    def set_report_bottom_margin(self):
        report_paper_id = self.env['report.paperformat'].search([('name','=','Custom Portrait A4')])
        if self.invoice_template_id == '7':
            report_paper_id.write({
                    'margin_bottom':75,
                    'margin_top':40
                })
        else:
            report_paper_id.write({
                    'margin_bottom':25,
                    'margin_top':30
                })


