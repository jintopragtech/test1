# -*- coding: utf-8 -*-
#########################################################################
#
#    MyFatoorah Payment Gateway
#    Copyright (C) 2021 Shilal Software Center.
#
##########################################################################
# ________________________________________________________________________


from odoo import api, fields, models, _


class ResCompany(models.Model):
    _inherit = "res.company"

    name = fields.Char(related='partner_id.name', string='Company Name', required=True, store=True, readonly=False, translate=True)
